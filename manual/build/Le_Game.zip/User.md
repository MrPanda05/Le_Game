# MANUAL DO JOGADOR

# Jogo do bacalhau!

### Feito por:
- Gabriel Alexsander da Costa Pereira
- Gabriel Duarte


# COMO RODAR ESSE JOGO?

1. Apos baixar e unzipar o arquivo
2. Abra o arquivo Le_Game.py
3. Executeo no seu IDE 

# COMO JOGAR?

Nesse jogo, vc deverar responder todas as perguntas, quanto mais acertos e quantos mais rodadas jogadas voce poderar
ganhar ou perder!!

Voce deverar escolher entre as respostas **A, B, C e D**

Voce, tambem podera usar alguns tipos de ajudas.
Para receber tal ajuda, se deve digitar as seguinte coisas

Apos o termino do jogo, voce poderar joga-lo novamente apenas rodando o arquivo novamente!


| Comando | Descricao | Usos|
| --- | --- | --- |
| Parar | Para de jogar o jogo | 1 |
| Pular | Pula um questao | 1 |
| 50 | Elemina 2 respostas | 2 |
| Universitarios | Escolhe 5 universitarios e faz com que eles escolherem uma questao, sera mostrado em porcentagem | 2 |
| Plateia | Escolhe 10 membros da plateia e faz com que eles escolherem uma questao, sera mostrado em porcentagem | 2 | 

## Agora voce ja dever estar com todo conhecimento necessario para jogar o jogo do bacalhau
